({
    baseUrl: ".",
    name: "gltf_app",
    out: "gltf_app.build.js",
    paths: {
        bimsurfer: "../bimsurfer/"
    },
    optimize: "none"
})
